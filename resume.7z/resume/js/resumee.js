//1

const arr = [
    {
        name: 'Jonny Wallker',
        birthDate: '1995-12-17'
    },
    {
        name: 'Andrew',
        birthDate: '2001-10-29'
    }
]

function searchByName(name, peopleArr){
    return peopleArr.filter(person => person.name === name)
}
console.log(arr[0];